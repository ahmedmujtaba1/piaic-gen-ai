# Serverless Python SaaS

[Serverless Computing 101: AWS Lambda and the Rise of Function-as-a-Service](https://www.internetkatta.com/serverless-computing-101-aws-lambda-and-the-rise-of-function-as-a-service)

[Getting started building serverless SaaS architectures](https://www.youtube.com/watch?v=Cag8cDbi-sk)

https://blog.awsfundamentals.com/aws-lambda-with-terraform

## Archtecture for Serverless Python

[The pragmatic serverless Python developer](https://www.youtube.com/watch?v=52W3Qyg242Y)

[Complete Presentation for Material](https://gist.github.com/heitorlessa/09e8bf8eb28d0e8dd96faf8db564f4a9)
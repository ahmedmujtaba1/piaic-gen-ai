# Terraform Hello World

[Download and Install Terraform](https://developer.hashicorp.com/terraform/install)

https://docs.aws.amazon.com/serverless-application-model/latest/developerguide/gs-terraform-support.html

Read the upto Page 59 of the book [Terraform: Up and Running, 3rd Edition](https://www.oreilly.com/library/view/terraform-up-and/9781098116736/)

[AWS Get Started](https://developer.hashicorp.com/terraform/tutorials/aws-get-started)

[Deploy serverless applications with AWS Lambda and API Gateway](https://developer.hashicorp.com/terraform/tutorials/aws/lambda-api-gateway)


[Download and Install Terraform](https://developer.hashicorp.com/terraform/install)

https://aws.amazon.com/blogs/compute/better-together-aws-sam-cli-and-hashicorp-terraform/

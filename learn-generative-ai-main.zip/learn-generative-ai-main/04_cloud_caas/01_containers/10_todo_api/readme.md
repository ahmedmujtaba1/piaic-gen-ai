# Todo REST API

https://github.com/geonaut/flask-todo-rest-api/tree/master

https://devcenter.heroku.com/articles/local-development-with-docker-compose

https://docs.docker.com/compose/environment-variables/set-environment-variables/


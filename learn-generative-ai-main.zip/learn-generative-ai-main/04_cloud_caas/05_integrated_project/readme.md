# Integrating AI, UI, and Persistance

We will develop a very simple Quiz app which will generate Questions using LLM.

In this app we will have a will have a topic class where the develop will create a topic tree and generate questions for each topic
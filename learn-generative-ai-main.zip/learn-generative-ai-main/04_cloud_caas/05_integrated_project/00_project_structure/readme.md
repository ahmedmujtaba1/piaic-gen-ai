# Python Project Structure

[Guide to Python Project Structure and Packaging](https://medium.com/mlearning-ai/a-practical-guide-to-python-project-structure-and-packaging-90c7f7a04f95)
# Session State

[Sesssion State](https://docs.streamlit.io/library/advanced-features/session-state)


Reference:

[Session State Docs](https://docs.streamlit.io/library/api-reference/session-state)


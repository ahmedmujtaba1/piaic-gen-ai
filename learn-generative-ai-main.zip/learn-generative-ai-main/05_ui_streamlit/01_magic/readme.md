# Magic

Magic commands are a feature in Streamlit that allows you to write almost anything (markdown, data, charts) without having to type an explicit command at all. Just put the thing you want to show on its own line of code, and it will appear in your app. 

https://docs.streamlit.io/library/api-reference/write-magic/magic
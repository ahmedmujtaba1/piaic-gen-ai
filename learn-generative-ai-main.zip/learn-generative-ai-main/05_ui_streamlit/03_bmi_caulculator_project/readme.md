# BMI Calculator

Let us recollect everything that we learn above and create a BMI Calculator web app.

The formula of BMI Index when weight is in Kgs and height is in meters is:

bmi = weight/height^2        

Reference and Code:

[A Beginners Guide To Streamlit](https://www.geeksforgeeks.org/a-beginners-guide-to-streamlit/)


Now Inhance Your BMI App by using the following Resources, with options for Adults, Children, etc.:

https://www.nhlbi.nih.gov/health/educational/lose_wt/BMI/bmicalc.htm

https://www.cdc.gov/healthyweight/assessing/bmi/adult_bmi/english_bmi_calculator/bmi_calculator.html

https://www.cdc.gov/healthyweight/bmi/calculator.html

https://www.nhs.uk/live-well/healthy-weight/bmi-calculator/

https://www.cdc.gov/healthyweight/bmi/calculator.html 



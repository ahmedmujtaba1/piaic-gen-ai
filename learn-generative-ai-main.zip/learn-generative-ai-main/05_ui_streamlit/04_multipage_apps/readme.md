# Multipage Apps

[Multipage Apps](https://docs.streamlit.io/library/get-started/multipage-apps)

https://github.com/Sven-Bo/streamlit-multipage-app-example
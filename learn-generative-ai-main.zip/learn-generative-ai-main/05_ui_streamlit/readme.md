# Learn Streamlit

We will learn from these resources:

[A Beginners Guide To Streamlit](https://www.geeksforgeeks.org/a-beginners-guide-to-streamlit/)

[Streamlit for Data Science: Create interactive data apps in Python 2nd ed. Edition](https://www.amazon.com/Streamlit-Data-Science-Create-interactive/dp/180324822X/ref=sr_1_1)

    pip install streamlit
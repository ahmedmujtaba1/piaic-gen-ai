# Build a basic LLM chat app

https://docs.streamlit.io/knowledge-base/tutorials/build-conversational-apps
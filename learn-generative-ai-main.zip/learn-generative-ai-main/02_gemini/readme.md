# Build with Gemini

Integrate Gemini models into your applications with Google AI Studio and Google Cloud Vertex AI. 

Available December 13th.

[Gemini Intro](https://deepmind.google/technologies/gemini/)
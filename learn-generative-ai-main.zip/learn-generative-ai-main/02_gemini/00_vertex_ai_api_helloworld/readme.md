# Generative AI Studio Hello World


[Introduction to Generative AI Studio](https://www.youtube.com/watch?v=-7nf5EJ2Fsc)

[Generative AI Studio](https://cloud.google.com/generative-ai-studio?hl=en)

[Comparision of Old OpenAI API and Vertex AI API](https://cloud.google.com/vertex-ai/docs/generative-ai/migrate-from-azure)

[Vertex AI Setup](https://cloud.google.com/vertex-ai/docs/featurestore/setup)

[This link is not working for me: GenAI Studio, may be they are updating](https://cloud.google.com/vertex-ai/docs/generative-ai/learn/generative-ai-studio)


Reference:

https://medium.com/google-cloud/deploying-a-google-cloud-generative-ai-app-in-a-website-with-cloud-run-7c8aa5db344 

All Faculty and Students please Register for Microsoft Azure and Google Cloud Accounts:


1. Microsoft Azure Account
https://azure.microsoft.com/en-us/free/ai-services/

Note: If possible register your account with a company email address.

Once you have a subscription id apply for Azure Open AI Service here:

https://azure.microsoft.com/en-us/products/ai-services/openai-service


2. Google Cloud Account
https://cloud.google.com/free
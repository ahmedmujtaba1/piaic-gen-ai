# Multimodal Prompting

[How it’s Made: Interacting with Gemini through multimodal prompting](https://developers.googleblog.com/2023/12/how-its-made-gemini-multimodal-prompting.html)

[Hands-on with Gemini: Interacting with multimodal AI](https://www.youtube.com/watch?v=UIZAiXYceBI)
# Docker on Vercel

https://twitter.com/TooTallNate/status/1727374632934879464

https://twitter.com/TooTallNate/status/1727392596614664535

Text Book:

https://www.amazon.com/Docker-Deep-Dive-Nigel-Poulton/dp/1916585256/ref=tmm_pap_swatch_0 


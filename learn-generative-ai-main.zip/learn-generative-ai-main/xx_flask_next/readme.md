# Next.js Flask Development

https://vercel.com/templates/next.js/nextjs-flask-starter
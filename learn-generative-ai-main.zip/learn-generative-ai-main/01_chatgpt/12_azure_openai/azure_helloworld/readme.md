# Azure OpenAI Service

[Azure OpenAI Service](https://azure.microsoft.com/en-us/products/ai-services/openai-service)

[Whats New?](https://learn.microsoft.com/en-us/azure/ai-services/openai/whats-new)

All Faculty and Students please Register for Microsoft Azure and Google Cloud Accounts:


1. Microsoft Azure Account
https://azure.microsoft.com/en-us/free/ai-services/

Note: If possible register your account with a company email address.

Once you have a subscription id apply for Azure Open AI Service here:

https://azure.microsoft.com/en-us/products/ai-services/openai-service


2. Google Cloud Account
https://cloud.google.com/free
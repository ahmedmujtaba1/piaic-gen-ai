# Multimodal Generative AI

https://openai.com/blog/chatgpt-can-now-see-hear-and-speak

https://www.marketsandmarkets.com/ResearchInsight/multimodal-ai-market.asp

Image Generation:

https://platform.openai.com/docs/guides/images?context=node

Vision:

https://platform.openai.com/docs/guides/vision

https://platform.openai.com/docs/api-reference/images

Text to Speech:

https://platform.openai.com/docs/guides/text-to-speech

Speech to Text:

https://platform.openai.com/docs/guides/speech-to-text


Audio:

https://platform.openai.com/docs/api-reference/audio








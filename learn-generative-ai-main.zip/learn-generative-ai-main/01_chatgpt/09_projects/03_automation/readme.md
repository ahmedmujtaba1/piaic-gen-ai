# Integrating OpenAI With Zapier For Smart Automations

https://www.linkedin.com/posts/zapier_add-ai-to-your-business-critical-workflows-activity-7011090580541751298-wKnW?utm_source=share&utm_medium=member_desktop

[How to combine OpenAI Assistant API and Zapier for no-code automations](https://www.geeky-gadgets.com/no-code-automations-assistant-api-zapier/)

https://www.youtube.com/watch?v=IPdL5QOuPMo

https://help.zapier.com/hc/en-us/articles/20965705530125-Use-OpenAI-s-Assistants-API-with-your-Zaps

https://zapier.com/blog/gpt-assistant/

Watch (23:29 to 25:44)
https://www.youtube.com/watch?v=U9mJuUkhUzk


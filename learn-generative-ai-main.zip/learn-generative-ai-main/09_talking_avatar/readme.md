# Talking Avatar

A talking avatar is a computer-generated character that can produce speech.

https://www.synthesia.io/glossary/talking-avatar

https://docs.synthesia.io/docs


Reference:

https://www.synthesia.io/post/best-ai-avatar-generator


# Documenting Python

[Watch: How To Create STUNNING Code Documentation With MkDocs Material Theme](https://www.youtube.com/watch?v=Q-YA_dA8C20)

[Code](https://github.com/james-willett/mkdocs-material-youtube-tutorial)

Reference:

[Getting Started Docs](https://squidfunk.github.io/mkdocs-material/getting-started/)
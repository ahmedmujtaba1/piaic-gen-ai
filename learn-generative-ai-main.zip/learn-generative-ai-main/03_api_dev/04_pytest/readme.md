# Testing Python

[pytest](https://docs.pytest.org/en/7.4.x/getting-started.html#getstarted)

Run the following command in root directory:

    pytest


pytest will run all files of the form test_*.py or *_test.py in the current directory and its subdirectories. 
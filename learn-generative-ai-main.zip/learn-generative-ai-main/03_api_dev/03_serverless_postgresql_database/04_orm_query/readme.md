# Writing SELECT statements for ORM Mapped Classes

https://docs.sqlalchemy.org/en/20/orm/queryguide/select.html
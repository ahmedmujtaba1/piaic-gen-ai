# Mapping Class Inheritance Hierarchies

https://docs.sqlalchemy.org/en/20/orm/inheritance.html


# Functions, Tools and Agents with LangChain


https://www.deeplearning.ai/short-courses/functions-tools-agents-langchain/
# Langchain

[6 Problems of LLMs That LangChain is Trying to Assess](https://www.kdnuggets.com/6-problems-of-llms-that-langchain-is-trying-to-assess)

https://nanonets.com/blog/langchain/

# Prompt Engineering

https://platform.openai.com/docs/guides/prompt-engineering/

https://www.deeplearning.ai/short-courses/chatgpt-prompt-engineering-for-developers/ 
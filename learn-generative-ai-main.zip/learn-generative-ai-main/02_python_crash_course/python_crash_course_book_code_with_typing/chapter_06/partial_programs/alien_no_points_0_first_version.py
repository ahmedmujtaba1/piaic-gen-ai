alien_0 = {'color': 'green', 'speed': 'slow'}
print(alien_0['points'])
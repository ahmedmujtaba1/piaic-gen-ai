motorcycles:list[str] = ['honda', 'yamaha', 'suzuki']

last_owned:str = motorcycles.pop()
print(f"The last motorcycle I owned was a {last_owned.title()}.")
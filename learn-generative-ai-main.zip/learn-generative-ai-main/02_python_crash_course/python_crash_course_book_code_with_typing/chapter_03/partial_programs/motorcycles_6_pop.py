motorcycles:list[str] = ['honda', 'yamaha', 'suzuki']
print(motorcycles)

popped_motorcycle:str = motorcycles.pop()
print(motorcycles)
print(popped_motorcycle)
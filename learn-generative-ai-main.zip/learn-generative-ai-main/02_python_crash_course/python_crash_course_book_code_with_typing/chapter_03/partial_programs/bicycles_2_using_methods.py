bicycles:list[str] = ['trek', 'cannondale', 'redline', 'specialized']
print(bicycles[0].title())

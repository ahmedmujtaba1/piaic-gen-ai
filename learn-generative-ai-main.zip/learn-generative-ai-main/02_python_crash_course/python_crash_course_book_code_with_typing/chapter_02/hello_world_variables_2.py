message:str = "Hello Python world!"
print(message)

message:str = "Hello Python Crash Course world!"
print(message)
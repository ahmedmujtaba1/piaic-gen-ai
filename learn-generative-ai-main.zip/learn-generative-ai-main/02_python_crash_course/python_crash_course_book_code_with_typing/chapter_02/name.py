name:str = "ada lovelace"
print(name.title())
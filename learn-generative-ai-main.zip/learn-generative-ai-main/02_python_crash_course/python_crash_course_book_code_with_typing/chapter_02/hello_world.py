message:str = "Hello Python world!"
print(message)
first_name:str = "ada"
last_name:str = "lovelace"
full_name:str = f"{first_name} {last_name}"
print(f"Hello, {full_name.title()}!")
first_name:str = "ada"
last_name:str = "lovelace"
full_name:str = f"{first_name} {last_name}"
message:str = f"Hello, {full_name.title()}!"
print(message)
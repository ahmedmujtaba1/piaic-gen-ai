def greet_user(username:str)->None:
    """Display a simple greeting."""
    print(f"Hello, {username.title()}!")
    
greet_user('jesse')

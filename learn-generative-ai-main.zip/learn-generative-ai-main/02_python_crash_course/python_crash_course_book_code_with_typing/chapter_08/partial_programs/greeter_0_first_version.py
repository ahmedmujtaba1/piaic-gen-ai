def greet_user()->None:
    """Display a simple greeting."""
    print("Hello!")
    
greet_user()
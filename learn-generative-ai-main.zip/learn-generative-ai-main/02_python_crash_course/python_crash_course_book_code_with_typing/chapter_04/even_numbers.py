even_numbers:list[int] = list(range(2, 11, 2))
print(even_numbers)
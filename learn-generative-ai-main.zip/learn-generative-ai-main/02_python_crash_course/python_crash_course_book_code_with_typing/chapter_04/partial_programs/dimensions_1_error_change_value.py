dimensions:tuple[int,int] = (200, 50)
dimensions[0] = 250
numbers:list[int] = list(range(1, 6))
print(numbers)
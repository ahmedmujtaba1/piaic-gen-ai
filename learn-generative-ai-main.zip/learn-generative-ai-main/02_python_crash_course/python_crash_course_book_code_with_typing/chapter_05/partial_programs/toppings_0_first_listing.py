requested_topping:str = 'mushrooms'

if requested_topping != 'anchovies':
    print("Hold the anchovies!")